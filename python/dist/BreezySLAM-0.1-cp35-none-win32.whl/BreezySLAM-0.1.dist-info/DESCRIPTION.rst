Provides core classes Position, Map, Laser, Scan, and algorithm CoreSLAM


